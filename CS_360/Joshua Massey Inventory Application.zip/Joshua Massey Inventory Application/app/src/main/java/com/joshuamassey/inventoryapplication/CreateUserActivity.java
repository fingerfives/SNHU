package com.joshuamassey.inventoryapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.joshuamassey.inventoryapplication.db.ApplicationDatabase;
import com.joshuamassey.inventoryapplication.db.entities.User;
import com.joshuamassey.inventoryapplication.util.SnackBarMessageUtil;

import java.util.List;

public class CreateUserActivity extends AppCompatActivity {

    private ApplicationDatabase db;
    private List<String> userNameList;

    EditText usernameInput;
    EditText passwordInput1;
    EditText passwordInput2;
    Button createButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_user);
        initComponents();
    }

    // OnClick handler for create button
    public void attemptCreateUser(View view) throws InterruptedException {
        AsyncTask.execute(() -> userNameList = db.userDAO().getUserNames());
        Thread.sleep(10);
        String userName = usernameInput.getText().toString();
        if (!passwordFieldsAreValid()) {
            SnackBarMessageUtil.showMismatchPasswordsError(view);
        } else if (userNameList != null && userNameList.contains(userName)) {
            SnackBarMessageUtil.showExistingUserMessage(view);
        } else {
            AsyncTask.execute(
                    () -> db.userDAO().addUser(
                            new User(userName, passwordInput1.getText().toString())
                    )
            );
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
    }

    // OnClick handler for cancel button
    public void cancelCreateActivity(View view) {
        super.onBackPressed();
    }

    private void initComponents() {
        db = ApplicationDatabase.getDatabase(this);
        usernameInput = findViewById(R.id.inputCreateUsername);
        passwordInput1 = findViewById(R.id.inputCreatePass1);
        passwordInput2 = findViewById(R.id.inputCreatePass2);
        createButton = findViewById(R.id.buttonCreateFinish);

        addListenerToInput(usernameInput);
        addListenerToInput(passwordInput1);
        addListenerToInput(passwordInput2);
    }

    private void addListenerToInput(EditText component) {
        component.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (usernameInput.getText().toString().length() != 0
                        && passwordInput1.getText().toString().length() != 0
                        && passwordInput2.getText().toString().length() != 0) {
                    createButton.setEnabled(true);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {}
        });
    }

    private boolean passwordFieldsAreValid() {
        String pass1 = passwordInput1.getText().toString();
        String pass2 = passwordInput2.getText().toString();
        return pass1.length() != 0
                && pass2.length() !=0
                && pass1.equals(pass2);
    }
}