package com.joshuamassey.inventoryapplication;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.joshuamassey.inventoryapplication.db.ApplicationDatabase;
import com.joshuamassey.inventoryapplication.db.entities.User;
import com.joshuamassey.inventoryapplication.util.SnackBarMessageUtil;

public class LoginActivity extends AppCompatActivity {

    private ApplicationDatabase db;
    private User user;

    private EditText usernameInput;
    private EditText passwordInput;
    private Button loginButton;
    private Button createButton;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        initComponents();
        addStubData();
    }

    // OnClick handler for Login button
    public void attemptLogin(View view) throws InterruptedException {
        String name = usernameInput.getText().toString();
        String pass = passwordInput.getText().toString();
        AsyncTask.execute(() -> user = db.userDAO().getUser(name, pass));
        Thread.sleep(70);
        if (user == null) {
            SnackBarMessageUtil.showLoginErrorMessage(view);
        } else {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
    }

    // OnClick handler for Create Account button
    public void launchCreateUserActivity(View view) {
        Intent intent = new Intent(this, CreateUserActivity.class);
        startActivity(intent);
    }

    private void initComponents() {
        db = ApplicationDatabase.getDatabase(this);
        usernameInput = findViewById(R.id.username);
        passwordInput = findViewById(R.id.password);
        loginButton = findViewById(R.id.loginButton);
        createButton = findViewById(R.id.createButton);
        addListenerToInput(usernameInput);
        addListenerToInput(passwordInput);
    }

    private void addStubData() {
        User u1 = new User("employee", "employee");
        User u2 = new User("admin", "admin");
        AsyncTask.execute(() -> db.userDAO().addUser(u1));
        AsyncTask.execute(() -> db.userDAO().addUser(u2));
    }

    // Adds logic to enable login button only when both fields have text
    private void addListenerToInput(EditText component) {
        component.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (usernameInput.getText().toString().length() != 0
                        && passwordInput.getText().toString().length() != 0) {
                    loginButton.setEnabled(true);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {}
        });
    }
}