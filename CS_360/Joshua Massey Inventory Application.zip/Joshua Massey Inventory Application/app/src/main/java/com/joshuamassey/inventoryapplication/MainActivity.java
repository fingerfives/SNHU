package com.joshuamassey.inventoryapplication;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.joshuamassey.inventoryapplication.db.ApplicationDatabase;
import com.joshuamassey.inventoryapplication.db.entities.Item;
import com.joshuamassey.inventoryapplication.util.PopupWindowCreator;
import com.joshuamassey.inventoryapplication.util.SnackBarMessageUtil;

import androidx.appcompat.app.AppCompatActivity;

import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;

import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;

import static androidx.core.content.ContextCompat.getSystemService;

public class MainActivity extends AppCompatActivity {

    private GridLayout itemGrid;
    private ApplicationDatabase db;
    private List<Item> items;
    private PopupWindowCreator creator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initComponents();
    }

    @Override
    public void onBackPressed() {
        // Do nothing: this disallows user going back to login screen
    }

    public void saveChanges(View view) {
        creator.saveChanges();
        loadItemsIntoGrid();
        closeWindow(view);
    }

    public void deleteItem(View view) {
        creator.deleteItem();
        loadItemsIntoGrid();
        closeWindow(view);
    }

    public void closeWindow(View view) {
        creator.dismissWindow();
    }

    // Creates callbacks for components
    private void initComponents() {
        db = ApplicationDatabase.getDatabase(this);
        itemGrid = findViewById(R.id.grid);
        loadItemsIntoGrid();
        createNotificationChannel();
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(v -> creator = new PopupWindowCreator(
                LayoutInflater.from(this), "add", null));
    }

    private void loadItemsIntoGrid() {
        itemGrid.removeAllViews();
        AsyncTask.execute(() -> items = db.itemDAO().getItems());
        try {
            Thread.sleep(50);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        for (Item item : items) {
            Button b = new Button(this);
            b.setText(Html.fromHtml("<b><big>" + item.getName() + "</big></b><br>" +
                    "Quantity: " + NumberFormat.getNumberInstance(Locale.US)
                                        .format(item.getQuantity())));
                            //NumberFormat call ensures larger numbers use commas
                            //ex: 10000 -> 10,000
            b.setBackgroundColor(Color.WHITE);
            b.setTextSize(12f);
            b.setTextColor(Color.BLACK);
            GridLayout.LayoutParams params= new GridLayout.LayoutParams(GridLayout.spec(
                    GridLayout.UNDEFINED,GridLayout.FILL,1f),
                    GridLayout.spec(GridLayout.UNDEFINED,GridLayout.FILL,1f));
            b.setLayoutParams(params);
            b.setOnClickListener((v) -> creator = new PopupWindowCreator(
                    LayoutInflater.from(this), "edit", item));
            itemGrid.addView(b);
        }
    }

    private void createNotificationChannel() {
        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "InventoryApplicationChannel";
            String description = "Notifies for out of stock items";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel("InventoryChannel", name, importance);
            channel.setDescription(description);
            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }
}