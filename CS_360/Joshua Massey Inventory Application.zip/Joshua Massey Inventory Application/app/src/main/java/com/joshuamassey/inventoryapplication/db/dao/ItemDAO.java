package com.joshuamassey.inventoryapplication.db.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.joshuamassey.inventoryapplication.db.entities.Item;

import java.util.List;

@Dao
public interface ItemDAO {

    @Query("SELECT * FROM items")
    List<Item> getItems();

    @Insert void addItem(Item item);
    @Update(onConflict = OnConflictStrategy.IGNORE) void updateItem(Item item);
    @Delete void removeItem(Item item);
}
