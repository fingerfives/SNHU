package com.joshuamassey.inventoryapplication.db.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.joshuamassey.inventoryapplication.db.entities.User;

import java.util.List;

@Dao
public interface UserDAO {

    @Query("SELECT * FROM user WHERE username = :username AND password = :password")
    User getUser(String username, String password);
    @Query("SELECT username FROM user")
    List<String> getUserNames();

    @Insert void addUser(User user);
}
