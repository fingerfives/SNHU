package com.joshuamassey.inventoryapplication.db.entities;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "items")
public class Item {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "itemID")
    private int itemID;

    @ColumnInfo(name = "name") private String name;
    @ColumnInfo(name = "quantity") private int quantity;

    public Item(String name, int quantity) {
        this.name = name;
        this.quantity = quantity;
    }

    public void setItemID(int itemID) { this.itemID = itemID; }
    public int getItemID() { return itemID; }
    public String getName() { return name; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
