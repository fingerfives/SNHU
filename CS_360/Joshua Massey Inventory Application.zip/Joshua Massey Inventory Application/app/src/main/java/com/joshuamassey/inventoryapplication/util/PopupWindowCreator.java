package com.joshuamassey.inventoryapplication.util;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.AsyncTask;
import android.os.Build;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.PopupWindow;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.joshuamassey.inventoryapplication.R;
import com.joshuamassey.inventoryapplication.db.ApplicationDatabase;
import com.joshuamassey.inventoryapplication.db.entities.Item;

import static androidx.core.content.ContextCompat.getSystemService;


public class PopupWindowCreator {

    private ApplicationDatabase db;
    private PopupWindow window;
    private Item item;
    private View view = null;

    ImageButton cancelButton;
    Button saveButton;
    EditText itemName;
    EditText itemQuantity;

    public PopupWindowCreator(LayoutInflater inflater, String popupToStart, Item item) {
        db = ApplicationDatabase.getDatabase(inflater.getContext());
        if (popupToStart.equals("add")) {
            view = inflater.inflate(R.layout.popup_add_item, null);
            setupAddComponents(view);
        } else if (popupToStart.equals("edit")) {
            this.item = item;
            view = inflater.inflate(R.layout.popup_edit_item, null);
            setupEditComponents(view);
        }
        addListenerToInput(itemQuantity);
        createPopupWindow(view);
    }

    public void dismissWindow() {
        window.dismiss();
    }

    public void saveChanges() {
        if (itemName != null) {
            Item i = new Item(itemName.getText().toString(), getQuantityFromInput());
            AsyncTask.execute(() -> db.itemDAO().addItem(i));
            notifyForNoInventory(i);
        } else {
            AsyncTask.execute(() -> db.itemDAO().updateItem(item));
            notifyForNoInventory(item);
        }
        try {
            Thread.sleep(10);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void deleteItem() {
        runQuery(() -> db.itemDAO().removeItem(item));
    }

    private void setupAddComponents(View view) {
        saveButton = view.findViewById(R.id.buttonSaveNewItem);
        cancelButton = view.findViewById(R.id.addItemCloseButton);
        itemName = view.findViewById(R.id.itemName);
        itemQuantity = view.findViewById(R.id.itemQuantityInput);
        addListenerToInput(itemName);
    }

    private void setupEditComponents(View view) {
        saveButton = view.findViewById(R.id.buttonSaveChanges);
        saveButton.setEnabled(true);
        cancelButton = view.findViewById(R.id.editItemCloseButton);
        itemQuantity = view.findViewById(R.id.changeQuantityInput);
        itemQuantity.setText(String.valueOf(item.getQuantity()));
        ImageButton subtractOne = view.findViewById(R.id.subtractItemQuantity);
        ImageButton addOne = view.findViewById(R.id.addItemQuantity);
        subtractOne.setOnClickListener(v -> {
            if (getQuantityFromInput() > 0) {
                itemQuantity.setText(String.valueOf(getQuantityFromInput() - 1));
                item.setQuantity(getQuantityFromInput())
;            }
        });
        addOne.setOnClickListener( v -> {
            itemQuantity.setText(String.valueOf(getQuantityFromInput() + 1));
            item.setQuantity(getQuantityFromInput());
        });
    }

    private void createPopupWindow(View v) {
        window = new PopupWindow(v, LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT, true);
        window.showAtLocation(v, Gravity.CENTER, 0, 0);
    }

    private void notifyForNoInventory(Item i) {
        NotificationCompat.Builder builder = new NotificationCompat
                .Builder(view.getContext(), "InventoryApplicationChannel")
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentTitle("Item Unavailable")
                .setContentText(i.getName() + " is out of stock")
                .setPriority(NotificationCompat.PRIORITY_LOW);
        NotificationManagerCompat notificationManager = NotificationManagerCompat
                                                            .from(view.getContext());
        notificationManager.notify(0, builder.build());
    }

    private void addListenerToInput(EditText component) {
        component.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (nameTextIsValid() && itemQuantity.getText().toString().length() != 0
                    && getQuantityFromInput() > -1) {
                    item.setQuantity(getQuantityFromInput());
                    saveButton.setEnabled(true);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {}
        });
    }

    private boolean nameTextIsValid() {
        // the itemName EditText component is null iff we are editing an existing entry
        return itemName == null || itemName.getText().toString().length() != 0;
    }

    private int getQuantityFromInput() {
        try {
            return Integer.parseInt(itemQuantity.getText().toString());
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private void runQuery(Runnable function) {
        AsyncTask.execute(function);
    }
}
