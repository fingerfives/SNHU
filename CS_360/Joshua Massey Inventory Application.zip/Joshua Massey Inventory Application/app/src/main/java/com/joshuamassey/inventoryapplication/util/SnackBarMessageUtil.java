package com.joshuamassey.inventoryapplication.util;

import android.content.Context;
import android.view.View;

import com.google.android.material.snackbar.Snackbar;

public class SnackBarMessageUtil {

    public static void showLoginErrorMessage(View v) {
        Snackbar.make(v, "Invalid login credentials", Snackbar.LENGTH_SHORT).show();
    }

    public static void showExistingUserMessage(View v) {
        Snackbar.make(v, "A user with this name already exists",
                Snackbar.LENGTH_SHORT).show();
    }

    public static void showMismatchPasswordsError(View v) {
        Snackbar.make(v, "Password fields do not match", Snackbar.LENGTH_SHORT).show();
    }

    public static void showItemDeletedMessage(View v) {
        Snackbar.make(v, "Item successfully deleted", Snackbar.LENGTH_SHORT).show();
    }

    public static void showItemSavedMessage(View v) {
        Snackbar.make(v, "Item successfully saved", Snackbar.LENGTH_SHORT);
    }
}
